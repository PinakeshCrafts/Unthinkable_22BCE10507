export async function GET() {
  // Mock metrics - in production, fetch from database
  const metrics = {
    totalSessions: 1247,
    escalatedSessions: 89,
    averageResponseTime: 245,
    averageConfidence: 0.82,
  }

  return Response.json(metrics)
}
