import { v4 as uuidv4 } from "uuid"

// In-memory session storage (replace with database in production)
const sessions = new Map()

export async function POST() {
  const sessionId = uuidv4()

  const sessionData = {
    sessionId,
    createdAt: new Date(),
    messages: [],
    escalated: false,
  }

  sessions.set(sessionId, sessionData)

  return Response.json(sessionData)
}
